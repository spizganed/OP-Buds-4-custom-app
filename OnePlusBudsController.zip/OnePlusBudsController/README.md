# OnePlus Buds Controller

Minimal Android app to control OnePlus Buds 4 (and compatible OPPO/Realme buds using OPOv1 protocol) via BLE GATT.

## Features
- ANC mode cycling (Off → Noise Cancellation → Transparency → Adaptive)
- Game Mode toggle
- Quick Settings tile (single tap = cycle ANC, long press = toggle Game Mode)
- Debug screen with packet log

## Build
1. Open in Android Studio or compile on-device with Android IDE / CodeAssist / Termux.
2. Grant Bluetooth permissions.
3. Ensure buds are paired and connected via system Bluetooth.

## Tile Usage
Add "Buds ANC" from the Quick Settings edit menu. Tap to cycle ANC, long-press to toggle Game Mode.

## Protocol Notes
- HELLO: `AA 07 00 00 00 01 23 00 00 12`
- REGISTER: `AA 0C 00 00 00 85 41 05 00 00 B5 50 A0 69`
- ANC: cmd `0x0404`, payload `01 01 01`=Off, `01 01 02`=NC, `01 01 04`=Transparency, `00 08`=Adaptive
- Game Mode: cmd `0x0403`, payload `28 01`=On, `28 00`=Off

If commands don't work, capture HCI snoop logs from the official app and adjust constants in `OpoProtocol.kt`.
